@extends('master')
@section('title','about')


@section('page')
about
@endsection