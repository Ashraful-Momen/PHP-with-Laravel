@extends('master')  

@section('title','Home')

@section ('title')
Home
@endsection