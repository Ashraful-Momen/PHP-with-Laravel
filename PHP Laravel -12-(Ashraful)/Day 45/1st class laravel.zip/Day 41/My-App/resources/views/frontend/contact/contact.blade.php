@extends('master')
@section('title','contact')

@section('page')
contact
@endsection



