
<?php $__env->startSection('title','contact'); ?>

<?php $__env->startSection('page'); ?>
page
<?php $__env->stopSection(); ?>




<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ashraful\Day 41\My-App\resources\views/frontend/contact/contact.blade.php ENDPATH**/ ?>