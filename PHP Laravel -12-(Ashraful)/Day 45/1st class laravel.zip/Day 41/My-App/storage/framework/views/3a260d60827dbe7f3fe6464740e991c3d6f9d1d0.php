  

<?php $__env->startSection('title','Home'); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ashraful\Day 41\My-App\resources\views/frontend/home/index.blade.php ENDPATH**/ ?>