

<p> Hello </p><?php /**PATH C:\xampp\htdocs\Ashraful\Day 41\My-App\resources\views/welcome.blade.php ENDPATH**/ ?>