<?php

use Illuminate\Support\Facades\Route;



Route::get('/', function () {
    return 'Home';
});

// Route::get('/about', function () {
//     return "About";
// });

Route::get('/contact', function () {
    return "Contact Page";
});

Route::get('/contact',function(){
    return view('frontend.contact.contact');
});

Route::get('/about',function(){
    return view('frontend.about.about');
});
Route::get('/',function(){
    return view('frontend.home.index');
});
