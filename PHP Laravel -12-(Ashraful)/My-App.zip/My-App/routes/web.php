<?php

use App\Http\Controllers\AboutController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\StudentController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ViewController;



// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/',[ViewController::class,'index'])->name('home');
Route::get('/about',[AboutController::class,'about'])->name('about');
Route::get('/contact',[ContactController::class,'contact'])->name('contact');
Route::get('/blog',[BlogController::class,'blog'])->name('blog');
Route::get('/student',[ViewController::class,'studentData'])->name('student');
Route::post('/adduser',[StudentController::class,'create'])->name('AddStudent');


