<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Student;

class StudentController extends Controller
{
   public function create(Request $request){
    $student = new Student();
    $student->name ="$request->name";
    $student->email ="$request->email";
    $student->password ="$request->password";
    $student->save();

    // return "Data Submited";
    // return $request->all();
    return redirect()->back()->with('msg','Student data save successfully');
   }
   
}
