<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Illuminate\Http\Request;

class ViewController extends Controller
{
    public function index(){
        return view('/frontend/home/index');
    }

    public function studentData(){

        $Students = Student::where('status',1)->get();
        return view('frontend.StudentData.student',compact('Students'));
    }
}
