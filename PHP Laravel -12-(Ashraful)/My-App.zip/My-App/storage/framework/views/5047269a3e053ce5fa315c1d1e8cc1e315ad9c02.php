

<?php $__env->startSection('page'); ?>
this is the vlog section
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ashraful\Day 47\My-App\resources\views//frontend/blog/blog.blade.php ENDPATH**/ ?>