

<?php $__env->startSection('page'); ?>
about page

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ashraful\Day 47\My-App\resources\views//frontend/about/about.blade.php ENDPATH**/ ?>