

<?php $__env->startSection('page'); ?>
<table class="table">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Id</th>
        <th scope="col">Name</th>
        <th scope="col">Email</th>
        <th scope="col">Password</th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $Students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
       
            
       
        <th scope="row"><?php echo e($data->id); ?></th>
        <td><?php echo e($data->name); ?></td>
        <td><?php echo e($data->email); ?></td>
        <td><?php echo e($data->password); ?></td>
        
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </tbody>
  </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ashraful\Day 47\My-App\resources\views/frontend/StudentData/student.blade.php ENDPATH**/ ?>