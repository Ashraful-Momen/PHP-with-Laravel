@extends('master')

@section('page')
contact page

@endsection