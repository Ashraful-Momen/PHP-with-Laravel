@extends('master')

@section('page')
this is the vlog section
@endsection