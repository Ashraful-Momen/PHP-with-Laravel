@extends('master')

@section('page')
about page

@endsection