@extends('master')

@section('title')
Home
@endsection

@section('page')
<section >
  <div class="container  ">
    <div class="row ">
      <div class="text-center   ">
        <p>{{Session::get('msg')}}</p>
        <h1>Student Registration</h1>
        <form action='{{route('AddStudent')}}' method="POST" class="W-50">
          @csrf
            <div class="form-outline mb-4">
                <input type="text" name='name' id="name" class="form-control" />
                <label class="form-label" for="name">Name:</label>
              </div>
            <!-- Email input -->
            <div class="form-outline mb-4">
              <input type="email" name='email'id="email" class="form-control" />
              <label class="form-label" for="email">Email address</label>
            </div>
          
            <!-- Password input -->
            <div class="form-outline mb-4">
              <input type="password" id="password" name='password'class="form-control" />
              <label class="form-label" for="password">Password</label>
            </div>
          
            <!-- 2 column grid layout for inline styling -->
            <div class="row mb-4">
              <div class="col d-flex justify-content-center">
                <!-- Checkbox -->
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="form1Example3" checked />
                  <label class="form-check-label" for="form1Example3"> Remember me </label>
                </div>
              </div>
          
              <div class="col">
                <!-- Simple link -->
                <a href="#!">Forgot password?</a>
              </div>
            </div>
          
            <!-- Submit button -->
            <button type="submit" class="btn btn-primary btn-block">Sign in</button>
          </form>
      </div>
    </div>
  </div>
 
  
</section>
@endsection