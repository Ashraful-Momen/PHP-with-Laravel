<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    //

    //show the product blade
    public function product()
    {
        $products = Post::latest()->paginate(5);
        return view("product", ['products' => $products]);
    }

    public function store(Request $request)
    {

        //test those validation and data save with ajax with return response()->json(); either getting lots of error.

        $request->validate(
            [
                "name" => "required ", // If we use unique then it will not work for ajax .
                "price" => "required",
            ],
            [
                "name.required" => "Name is required",
                "name.unique" => "Product already exits", // this condition is not working
                "price.required" => "Price is required",
            ]

        );

        // dd($request);


        $product = new Post();
        $product->name = $request->name;
        $product->price = $request->price;
        $product->save();


        return response()->Json([
            "status" => "success",
        ]);
    }

    // public function update(Request $request)
    // {


    //     dd($request->all());


    //     //test those validation and data save with ajax with return response()->json(); either getting lots of error.

    //     // $request->validate(
    //     //     [
    //     //         "up_name" => "required |unique:product,name,".$request->up_id, // If we use unique then it will not work for ajax .
    //     //         "up_price" => "required",
    //     //     ],
    //     //     [
    //     //         "name.required" => "Name is required",
    //     //         "name.unique" => "Product already exits",// this condition is not working
    //     //         "price.required" => "Price is required",
    //     //         ]

    //     //     );






    //     $product = Post::where('id',$request->up_id)->get();
    //     $product::update([
    //         'name' => $request->up_name,
    //         'price' =>$request->up_price,
    //     ]);


    //     return response()->Json([
    //         "status"=> "success",
    //     ]);


    // }



    public function update(Request $request)
    {



        // Validate request data
        $request->validate([
            "up_name" => "required",
            "up_price" => "required",
        ], [
            "up_name.required" => "Name is required",
            "up_name.unique" => "Product already exists",
            "up_price.required" => "Price is required",
        ]);

        // Update product
        $product = Post::find($request->up_id);
        $product->name = $request->up_name;
        $product->price = $request->up_price;
        $product->save();

        return response()->json([
            "status" => "success",
        ]);
    }

    public function delete(Request $request){

        $product = Post::find($request->id)->delete();

        return response()->json([
            "status" => "success",
        ]);
    }

    public function pagination(){
        $products = Post::latest()->paginate(5);
        return view("product_pagination", ['products' => $products])->render(); //now this view will render to the ajax functon product(page);
    }


    public function search(Request $request){
        $products = Post::where('name','like', '%'.$request->search.'%')
        ->orWhere('price','like', '%'.$request->search.'%')
        ->orderBy('id','desc')->paginate(5);

        if($products->count() >= 1){
            return view("product_pagination", ['products' => $products])->render();
        }
        else{
            return response()->json([
                'status'=>'nothing_found',
            ]);
        }
    }

}
