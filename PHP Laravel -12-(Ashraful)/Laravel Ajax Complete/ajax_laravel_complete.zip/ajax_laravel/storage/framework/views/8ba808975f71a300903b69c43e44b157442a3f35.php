
    
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
    <script>
        $(document).ready(function() {
            // alert("this is the check for the alert");

            // when the add product button is clicked, then trigger the function
            $(document).on('click', '.add_product_btn', function(e) {
                e.preventDefault();
                let name = $('#name').val();
                let price = $('#price').val();

                console.log(name,price); // without  this line can't dd() from controller

                $.ajax({
                    url:"<?php echo e(route('product.store')); ?>",
                    method:"POST",
                    data: {
                        name:name,
                        price:price,
                    },
                    success:function(res){ // if controller return response()->Json(). then this success function will work.

                        if(res.status=="success"){ //this res.status comes form controller json response array.

                            $('#addProductModal').modal('hide'); //close the modal, after submiting.
                            $('#addProductForm')[0].reset(); //reset the form(input field), after submiting.
                            $('.table').load(location.href+' .table'); // reload the table after submiting. auto refreshing the table.

                        }

                    },
                    error:function(err){ //if controller return response()->Json(). then this error function will work. and show the validation error .
                        let error = err.responseJSON; // controller return response()->Json(). get the error from the laravel store function validation.

                        // console.log(error.errors);
                        // display the error in a div product blade.
                        $.each(error.errors,
                            function(key, value){
                            $('.errorMsgContainer').append('<p class="text-danger">'+value+'</p>'+'</br>');
                        }
                            )
                    },



                })
            })

            //update product:
            $document.on('click','#edit_btn',function(e){


                //edit button data-id, data-name, data-price =>  this is the product blade.
                let id = $(this).data('id');
                let name = $(this).data('name');
                let price = $(this).data('price');


                //update modal data-id, data-name, data-price =>  this is the update blade.
                $('#up_id').val(id); //hidden field .val(let id)
                $('#up_name').val(name); //.val(let name)
                $('#up_price').val(price); //.val(let price)



            })
        })
    </script>
<?php /**PATH /home/shuvo/Laravel/LaravelAjax/ajax_laravel/resources/views/product_ajax_file.blade.php ENDPATH**/ ?>