<div class="table-data">
   

    <table class="table border  text-center">
        <thead>
            <tr>
                <th scope="col">Id</th>
                <th scope="col">Name</th>
                <th scope="col">Price</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($key + 1); ?></th>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e($product->price); ?></td>
                    <td>
                        <a href="" data-bs-target="#updateProductModal" data-bs-toggle="modal"
                            data-id="<?php echo e($product->id); ?>" data-name="<?php echo e($product->name); ?>"
                            data-price="<?php echo e($product->price); ?>"
                            class="edit_btn"
                            id="edit_btn">
                            <button class="btn btn-primary">Edit</button>
                        </a>
                        <a href=""  data-id="<?php echo e($product->id); ?>" class="delete_btn" >

                            <button class="btn btn-danger">Delete</button>

                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
     <?php echo e($products->links()); ?>

</div>
<?php /**PATH /home/shuvo/Laravel/LaravelAjax/LaravelAjax/ajax_laravel/resources/views/product_pagination.blade.php ENDPATH**/ ?>