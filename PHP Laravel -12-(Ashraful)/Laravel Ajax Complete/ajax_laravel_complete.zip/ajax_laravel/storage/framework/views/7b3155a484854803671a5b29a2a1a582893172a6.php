<!-- Button trigger modal -->


  <!-- Modal -->
  <div class="modal fade" id="updateProductModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Update Product </h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div class="errorMsgContainer">
                
            </div>
          <form action="" method="post" id="updateProductForm">
            <?php echo csrf_field(); ?>
            <input hidden  id="up_id">
            <label for="name">Add Product Name</label>
            <input type="text" class="form-control mb-3" id="up_name" name="up_name" id="name">
            <label for="name">Add Product Price</label>
            <input type="number" class="form-control" id="up_price" name="up_price" id="price">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary update_product_btn">Update Product</button>
        </div>
    </form>
      </div>
    </div>
  </div>
<?php /**PATH J:\Laravel Practise\Laravel Ajax backup\LaravelAjax\ajax_laravel\resources\views/product_update_modal.blade.php ENDPATH**/ ?>