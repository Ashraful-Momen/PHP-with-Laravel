

<script src="https://code.jquery.com/jquery-3.7.1.min.js"
    integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
</script>
<script>
    $(document).ready(function() {
        // alert("this is the check for the alert");

        //add product ajax function: ______________________________
        // when the add product button is clicked, then trigger the function
        $(document).on('click', '.add_product_btn', function(e) {
            e.preventDefault();
            let name = $('#name').val();
            let price = $('#price').val();

            console.log(name, price); // without  this line can't dd() from controller

            $.ajax({
                url: "<?php echo e(route('product.store')); ?>",
                method: "POST",
                data: {
                    name: name,
                    price: price,
                },
                success: function(
                    res
                ) { // if controller return response()->Json(). then this success function will work.

                    if (res.status ==
                        "success"
                    ) { //this res.status comes form controller json response array.

                        $('#addProductModal').modal(
                            'hide'); //close the modal, after submiting.
                        $('#addProductForm')[0]
                            .reset(); //reset the form(input field), after submiting.
                        $('.pageReload').load(location.href +
                            ' .pageReload'
                        ); // reload the table after submiting. auto refreshing the table.

                    }

                },
                error: function(
                    err
                ) { //if controller return response()->Json(). then this error function will work. and show the validation error .
                    let error = err
                        .responseJSON; // controller return response()->Json(). get the error from the laravel store function validation.

                    // console.log(error.errors);
                    // display the error in a div product blade.
                    $.each(error.errors,
                        function(key, value) {
                            $('.errorMsgContainer').append('<p class="text-danger">' +
                                value + '</p>' + '</br>');
                        }
                    )
                },



            })
        })

        //update product value in update modal: modal _________________________
        $(document).on('click', '#edit_btn', function(e) {


            //edit button data-id, data-name, data-price =>  this is the product blade.
            let id = $(this).data('id'); //those value get from edit button =>id,name,price.
            let name = $(this).data('name');
            let price = $(this).data('price');

            // console.log(id,name,price);


            //update modal data-id, data-name, data-price =>  this is the update blade.
            $('#up_id').val(id); //hidden field .val(let id)
            $('#up_name').val(name); //.val(let name)
            $('#up_price').val(price); //.val(let price)

        })

        //update ajax function : ____________________________________
        $(document).on('click', '.update_product_btn', function(e) {
            e.preventDefault();
            let id = $('#up_id').val();
            let name = $('#up_name').val();
            let price = $('#up_price').val();

            console.log(id, name, price);

            $.ajax({
                url: "<?php echo e(route('product.update')); ?>",
                method: "POST",
                data: {
                    up_id: id,
                    up_name: name,
                    up_price: price,
                    // Corrected the variable names and values
                },
                success: function(res) {
                    if (res.status == "success") {
                        $('#updateProductModal').modal('hide');
                        $('#updateProductForm')[0].reset();
                        $('.table').load(location.href + ' .table');
                    }
                },
                error: function(err) {
                    let error = err.responseJSON;
                    $('.errorMsgContainer').empty(); // Clear previous error messages
                    $.each(error.errors, function(key, value) {
                        $('.errorMsgContainer').append('<p class="text-danger">' +
                            value + '</p>');
                    });
                },
            });
        });

        //delete product : ________________________________________

        $(document).on('click', '.delete_btn', function(e) {
            e.preventDefault();
            let product_id = $(this).data('id');
            console.log(product_id);
            if (confirm("Are you sure to delete?")) {
                $.ajax({
                    url: "<?php echo e(route('product.delete')); ?>",
                    method: "POST",
                    data: {
                        id: product_id,
                    },
                    success: function(res) {
                        if (res.status == "success") {

                            $('.table').load(location.href + ' .table');
                        }
                    },

                });
            }
        })

        //pagination : __________________________________________
        $(document).on('click', '.pagination a', function(e) {
            e.preventDefault();
            let page = $(this).attr('href').split('page=')[
            1]; //in pagination class we just collect page number , example: page=2
            // console.log(page);
            product(page);
        })

        function product(page) {
            $.ajax({
                url: "/pagination/paginate-data?page=" + page,
                success: function(res) {
                    $('.table-data').html(
                    res); //load the table when controller pagination function return response and render the table view.
                }
            })
        }

        //search: _________________________________________

        $(document).on('keyup', '#search', function(e) {
            e.preventDefault();
            let search = $(this).val();
            console.log(search);
            $.ajax({
                url: "<?php echo e(route('product.search')); ?>",
                method: "get",
                data: {
                    search: search
                },
                success: function(res) {
                    $('.table-data').html(res); //load the table when controller pagination function return response and render the table view.
                    if (res.status == "nothing_found") {
                        $('.table-data').html('<span class="text-danger">' +
                            'Nothing Found' + '</span>');
                    }
                }
            });
        });


    })
</script>
<?php /**PATH /home/shuvo/Laravel/LaravelAjax/LaravelAjax/ajax_laravel/resources/views/product_ajax_file.blade.php ENDPATH**/ ?>