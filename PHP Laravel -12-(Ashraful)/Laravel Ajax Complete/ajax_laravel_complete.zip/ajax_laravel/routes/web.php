<?php

use App\Http\Controllers\ProductController;
use Illuminate\Support\Facades\Route;





Route::get('/', [ProductController::class, 'product'])->name('product');

Route::post('/product_store', [ProductController::class, 'store'])->name('product.store');
Route::post('/product_update', [ProductController::class, 'update'])->name('product.update');
Route::post('/product_delete', [ProductController::class, 'delete'])->name('product.delete');
Route::get('/pagination/paginate-data', [ProductController::class, 'pagination'])->name('product.pagination');
Route::get('/search', [ProductController::class, 'search'])->name('product.search');
