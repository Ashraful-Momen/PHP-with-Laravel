<div class="table-data">
   

    <table class="table border  text-center">
        <thead>
            <tr>
                <th scope="col">Id</th>
                <th scope="col">Name</th>
                <th scope="col">Price</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            {{-- @php
                dd($products);
            @endphp --}}

            @foreach ($products as $key => $product)
                <tr>
                    <th scope="row">{{ $key + 1 }}</th>
                    <td>{{ $product->name }}</td>
                    <td>{{ $product->price }}</td>
                    <td>
                        <a href="" data-bs-target="#updateProductModal" data-bs-toggle="modal"
                            data-id="{{ $product->id }}" data-name="{{ $product->name }}"
                            data-price="{{ $product->price }}"
                            class="edit_btn"
                            id="edit_btn">
                            <button class="btn btn-primary">Edit</button>
                        </a>
                        <a href=""  data-id="{{ $product->id }}" class="delete_btn" >

                            <button class="btn btn-danger">Delete</button>

                        </a>
                    </td>
                </tr>
            @endforeach

        </tbody>
    </table>
     {{ $products->links() }}
</div>
