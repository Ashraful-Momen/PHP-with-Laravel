

<?php $__env->startSection('title','Shuvo::2nd class::AboutPage'); ?>
<?php $__env->startSection('page'); ?>
<h3>About page</h3>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ashraful\Day 46\2nd Class laravel\My-App\resources\views/frontend/about/about.blade.php ENDPATH**/ ?>