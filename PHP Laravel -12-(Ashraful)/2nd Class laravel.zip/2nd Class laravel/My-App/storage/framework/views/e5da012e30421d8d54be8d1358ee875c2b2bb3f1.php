

<?php $__env->startSection('title','Shuvo::2nd class::ContactPage'); ?>
<?php $__env->startSection('page'); ?>

  <div class="container-fluid ">
    <div class="row myclass justify-content-center">
        <h1 class="text-center">User Registration</h1>
        <form action=" " class="from w-50 p-2 text-white" >
            <div class="mb-3">
                <label>Name:</label>
                <input type="text" name="Name" class="form-control">
            </div>
            <div class="mb-3">
                <label>Email:</label>
                <input type="email" name="Name" class="form-control">

            </div>
            <div class="mb-3">
                <label>Password:</label>
                <input type="password" name="password" class="form-control">
            </div>
            <div class="mb-3">
                <label>RePassword:</label>
                <input type="password" name="password" class="form-control">
                <div class="p-2 mb-3 form-text">You will remain in private , we won't share anyone</div>
            </div>
            <div class="p-2 m3 form-check-inline">
                <input type="radio" class="form-check-input" id="Male">
                <label for="Male">Male</label>
            </div>
            <div class="p-2 m3 form-check-inline">
                <input type="radio" class="form-check-input" id="Female">
                <label for="Female">Female</label>
            </div>
            <div class="mb-3">
                <label for="department">Department</label>
                <select name="Department" id="department" class="form-select-inline rounded">
                    <option value="cse" selected >CSE</option>
                    <option value="eee">EEE</option>
                    <option value="eee">BBA</option>
                </select>
            </div>
            <div class="p-2 m3 form-checkbox">
                <input type="checkbox" class="form-checkbox" id="tnc">
                <label for="tnc">Accept terms and condition</label>
            </div>

            <div class="mb-3 p-2 form-submit">
                <button type="submit" class="btn btn-dark">
                    submit
                </button>
            </div>
        </form>
    </div>
  </div>
  <!-- Bootstrap JavaScript Libraries -->
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ashraful\Day 46\2nd Class laravel\My-App\resources\views/frontend/contact/contact.blade.php ENDPATH**/ ?>