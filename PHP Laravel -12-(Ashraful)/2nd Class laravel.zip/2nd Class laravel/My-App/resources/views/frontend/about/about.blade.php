@extends('app')

@section('title','Shuvo::2nd class::AboutPage')
@section('page')
<h3>About page</h3>
@endsection