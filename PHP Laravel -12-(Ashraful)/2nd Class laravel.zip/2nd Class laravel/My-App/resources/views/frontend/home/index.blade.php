@extends('app')

@section('title','Shuvo::2nd class::HomePage')
@section('page')
<h3>Home page</h3>
@endsection


