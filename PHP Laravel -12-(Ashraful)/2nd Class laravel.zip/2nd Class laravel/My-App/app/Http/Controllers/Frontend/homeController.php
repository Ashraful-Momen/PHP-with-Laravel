<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
// use Illuminate\Http\Request;

class homeController extends Controller
{
    public function index(){

        // return 'Home Page';
        return view('frontend/home/index');
    }
    public function contact(){

        // return 'Home Page';
        return view('frontend.contact.contact');
    }
    public function about(){

        // return 'Home Page';
        return view('frontend/about/about');
    }
    // public function create(){
        
    // }
    // public function store(){
        
    // }
    // public function edit(){
        
    // }
    // public function update(){
        
    // }
    // public function delete(){
        
    // }
}
