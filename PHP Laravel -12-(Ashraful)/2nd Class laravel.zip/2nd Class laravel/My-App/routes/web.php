<?php

use App\Http\Controllers\Frontend\AboutController;
use App\Http\Controllers\Frontend\homeController;
use Illuminate\Support\Facades\Route;


// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/',[homeController::class,'index']);
Route::get('/contact',[homeController::class,'contact']);

Route::get('/about',[AboutController::class,'about']);