

<?php $__env->startSection('page'); ?>
<div class="container">
    <div class="row">
        <div class="col-12 mx-auto my-2  border border-primary rounded">
            <table class="table">
                <thead>
                  <tr>
                   
                    <th scope="col">Id</th>
                    <th scope="col">Status</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Password</th>
                    <th scope="col">file</th>
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $Portals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                   
                        
                   
                    
                    
            
                    <th scope="row"><?php echo e($data->id); ?></th>
                    <td><?php echo e($data->status); ?></td>
                    <td><?php echo e($data->name); ?></td>
                    <td><?php echo e($data->email); ?></td>
                    <td><?php echo e($data->phone); ?></td>
                    <td><?php echo e($data->password); ?></td>
                    
                    <td> <img width="30%" class="img-circle" src="<?php echo e(asset($data->file)); ?>"> </td>
                    
                    
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                </tbody>
              </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ashraful\Day 48\Laravel-4\resources\views/frontend/portal/portal.blade.php ENDPATH**/ ?>