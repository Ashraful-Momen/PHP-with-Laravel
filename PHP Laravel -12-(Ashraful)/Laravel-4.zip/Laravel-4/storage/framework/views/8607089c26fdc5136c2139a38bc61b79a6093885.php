

<?php $__env->startSection('page'); ?>
<table class="table">
    <thead>
      <tr>
       
        <th scope="col">Id</th>
        <th scope="col">Status</th>
        <th scope="col">Name</th>
        <th scope="col">Email</th>
        <th scope="col">Phone</th>
        <th scope="col">Password</th>
        <th scope="col">file</th>
      </tr>
    </thead>
    <tbody>
        
      <tr>
       
            
       
        <th scope="row">ID</th>
        <td>status</td>
        <td>name</td>
        <td>email</td>
        <td>phone</td>
        <td>password</td>
        <td>file</td>
        

        
        
      </tr>
      
      
    </tbody>
  </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ashraful\Day 48\Laravel-4\resources\views//frontend/portal/portal.blade.php ENDPATH**/ ?>