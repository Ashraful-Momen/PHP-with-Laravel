<?php

use App\Http\Controllers\Frontend\DataReceiveController;
use App\Http\Controllers\Frontend\HomeController;
use App\Http\Controllers\Frontend\PortalController;
use Illuminate\Support\Facades\Route;



// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/',[HomeController::class,'index'])->name('home');


Route::post('/',[DataReceiveController::class,'dataReceive'])->name('dataReceive');

Route::get('/portal',[PortalController::class,'portal'])->name('portal');