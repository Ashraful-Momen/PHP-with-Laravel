@extends('master')

@section('title')
Home Page

@endsection


@section('page')
<section >
  <div class="container  ">
    <div class="row col-6 mx-auto">
      <div class="  border border-primary rounded mt-2 bg-warning">
        {{-- <p>{{Session::get('msg')}}</p> --}}
        <h1>Student Registration</h1>
        <form action='{{route('dataReceive')}}' method="POST" class="  " enctype="multipart/form-data">
          @csrf
            <div class="form-outline mb-4">
                <label class="form-label" for="name">Name:</label>
                <input type="text" name='name' id="name" class="form-control" />
                
              </div>
            <!-- Email input -->
            <div class="form-outline mb-4">
              <label class="form-label" for="email">Email address</label>
              <input type="email" name='email'id="email" class="form-control" />
              
            </div>
          {{-- phone --}}
          <div class="form-outline mb-4">
            <label class="form-label" for="phone">Phone</label>
            <input type="string" id="phone" name='phone'class="form-control" />
            
          </div>
            <!-- Password input -->
            <div class="form-outline mb-4">
                <label class="form-label" for="password">Password</label>
              <input type="password" id="password" name='password'class="form-control" />
              
            </div>
            {{-- File --}}
            <div class="form-outline mb-4">
                <input type="file" id="file" name='file'class="form-control" />
                <label class="form-label" for="file">File</label>
              </div>
          
            <!-- 2 column grid layout for inline styling -->
            <div class="row mb-4">
              <div class="col d-flex justify-content-center">
                <!-- Checkbox -->
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="form1Example3" checked />
                  <label class="form-check-label" for="form1Example3"> Remember me </label>
                </div>
              </div>
          
              <div class="col">
                <!-- Simple link -->
                <a href="#!">Forgot password?</a>
              </div>
            </div>
          
            <!-- Submit button -->
            <button type="submit" class="btn btn-primary btn-block">Sign in</button>
          </form>
      </div>
    </div>
  </div>
 
  
</section>
@endsection
