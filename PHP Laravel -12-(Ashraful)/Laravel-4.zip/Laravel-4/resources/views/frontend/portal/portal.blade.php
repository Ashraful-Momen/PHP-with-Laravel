@extends('master')

@section('page')
<div class="container">
    <div class="row">
        <div class="col-12 mx-auto my-2  border border-primary rounded">
            <table class="table">
                <thead>
                  <tr>
                   
                    <th scope="col">Id</th>
                    <th scope="col">Status</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Password</th>
                    <th scope="col">file</th>
                  </tr>
                </thead>
                <tbody>
                    @foreach ($Portals as $data)
                  <tr>
                   
                        
                   
                    {{-- <th scope="row">ID</th>
                    <td>status</td>
                    <td>name</td>
                    <td>email</td>
                    <td>phone</td>
                    <td>password</td>
                    <td>file</td> --}}
                    
            
                    <th scope="row">{{$data->id}}</th>
                    <td>{{$data->status}}</td>
                    <td>{{$data->name}}</td>
                    <td>{{$data->email}}</td>
                    <td>{{$data->phone}}</td>
                    <td>{{$data->password}}</td>
                    {{-- <td> <img src="{{ asset('uploads/appsetting/' . $data->file) }}" /> </td> --}}
                    <td> <img width="30%" class="img-circle" src="{{ asset($data->file) }}"> </td>
                    {{-- <td>{{$data->file}}</td> --}}
                    
                  </tr>
                  @endforeach
                  
                </tbody>
              </table>
        </div>
    </div>
</div>
@endsection