<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Portals;
use Illuminate\Http\Request;

class PortalController extends Controller
{
    public function portal(Request $request){
        $Portals = Portals::where('status',1)->get();
        return view('frontend.portal.portal',compact('Portals'));


        
    }
}
