<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Portals;

class DataReceiveController extends Controller
{
    public function dataReceive(Request $request){

        

        $portal = new Portals();
        $portal->name = "$request->name";
        $portal->email = "$request->email";
        $portal->phone = "$request->phone";
        $portal->password = "$request->password";

        $image = $request->file;
        // $folder = 'Student-img';
        $imageName=time().$image->getClientOriginalName();
        if($image){

            $image->move('portal_image', $imageName);
            $portal->file = 'portal_image'."/". $imageName;
        }
       
        $portal->save();
        return redirect()->route('home');
    }
}
